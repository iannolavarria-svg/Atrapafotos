from flask import Flask, render_template_string, request, send_from_directory
from werkzeug.utils import secure_filename
import os

app = Flask(__name__)
UPLOAD_FOLDER = "uploads"
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

HTML = """<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>App Gestos Tablet Ultra Visual</title>
<style>
body { font-family: 'Segoe UI', Arial; background:#121212; color:#fff; text-align:center; padding:10px;}
h1 { color:#ff6f61; margin-bottom:10px; text-shadow:0 0 10px #ff6f61; font-size:2em;}
button{ padding:12px 20px; margin:8px; border:none; border-radius:12px; background:#00bfff; color:#fff; cursor:pointer; font-weight:bold; transition:.3s;}
button:hover {background:#009acd; transform:scale(1.05);}
#cameras{ display:flex; flex-wrap:wrap; justify-content:center; gap:20px; margin-top:20px;}
video{ border:3px solid #ff6f61; border-radius:12px; max-width:45vw;}
#selectedImage{ max-width:40vw; margin-top:20px; border-radius:12px; box-shadow: 0 0 20px #00ffff; transition: transform 0.8s ease, opacity 0.8s ease;}
#image-container{position:relative; display:inline-block;}
#trail{position:absolute; top:0; left:0; width:100%; height:100%; pointer-events:none;}
#message{margin-top:10px; font-size:1.1em;}
</style>
</head>
<body>
<h1>Gestos Tablet Ultra Visual</h1>

<form method="post" enctype="multipart/form-data">
<input type="file" name="galeria" accept="image/*">
<button type="submit">Cargar Imagen</button>
</form>

<p id="message">{{ mensaje }}</p>

<div id="cameras">
<div>
<h3>Frontal</h3>
<video id="frontal" autoplay></video>
</div>
<div>
<h3>Trasera</h3>
<video id="trasera" autoplay></video>
</div>
</div>

<div id="image-container">
<canvas id="trail"></canvas>
{% if uploaded_image %}
<img id="selectedImage" src="{{ uploaded_image }}" alt="Imagen seleccionada">
{% endif %}
</div>

<script src="https://cdn.jsdelivr.net/npm/@mediapipe/hands/hands.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@mediapipe/camera_utils/camera_utils.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@mediapipe/drawing_utils/drawing_utils.js"></script>

<script>
let fistClosed = false;
let startPos = null;

const trailCanvas = document.getElementById('trail');
const ctx = trailCanvas.getContext('2d');
function resizeCanvas(){ trailCanvas.width = window.innerWidth; trailCanvas.height = window.innerHeight;}
window.addEventListener('resize', resizeCanvas);
resizeCanvas();

function drawTrail(x, y){
    ctx.fillStyle = 'rgba(0, 255, 255, 0.3)';
    ctx.beginPath();
    ctx.arc(x, y, 20, 0, Math.PI*2);
    ctx.fill();
    ctx.fillStyle = 'rgba(0,0,0,0.05)';
    ctx.fillRect(0,0,trailCanvas.width, trailCanvas.height);
}

async function startCameras(){
    try{
        const frontalStream = await navigator.mediaDevices.getUserMedia({video:{facingMode:"user", width:{ideal:640}, height:{ideal:480}}});
        document.getElementById('frontal').srcObject = frontalStream;

        const traseraStream = await navigator.mediaDevices.getUserMedia({video:{facingMode:"environment", width:{ideal:640}, height:{ideal:480}}});
        document.getElementById('trasera').srcObject = traseraStream;

        startGestureDetection();
    }catch(err){ alert("Error al acceder a las cámaras: "+err);}
}

function startGestureDetection(){
    const video = document.getElementById('frontal');
    const hands = new Hands({locateFile:(file)=>`https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`});
    hands.setOptions({maxNumHands:1,minDetectionConfidence:0.7,minTrackingConfidence:0.7});
    
    hands.onResults(results=>{
        if(results.multiHandLandmarks && results.multiHandLandmarks.length>0){
            const landmarks = results.multiHandLandmarks[0];
            let fist = true;
            for(let i=5;i<=20;i+=4){ if(landmarks[i].y < landmarks[i-2].y) fist=false; }

            if(fist && !fistClosed){
                fistClosed = true;
                startPos = {x: landmarks[9].x, y: landmarks[9].y};
            }

            if(!fist && fistClosed){
                fistClosed = false;
                let endPos = {x: landmarks[9].x, y: landmarks[9].y};
                launchImageWithTrail(startPos,endPos);
            }

            const x = landmarks[9].x*window.innerWidth;
            const y = landmarks[9].y*window.innerHeight;
            drawTrail(x, y);
        }
    });

    const camera = new Camera(video,{
        onFrame: async()=>{ await hands.send({image:video}); },
        width:640,
        height:480
    });
    camera.start();
}

function launchImageWithTrail(start,end){
    const img = document.getElementById('selectedImage');
    if(!img) return;

    const deltaX = (end.x - start.x) * 600; 
    const deltaY = (start.y - end.y) * 600;

    img.style.transition="transform 0.8s ease-out, opacity 0.8s ease-out, box-shadow 0.8s ease-out";
    img.style.transform=`translate(${deltaX}px, ${deltaY}px) scale(0.4)`;
    img.style.opacity="0";
    img.style.boxShadow="0 0 50px #00ffff";

    setTimeout(()=>{
        img.style.transform="";
        img.style.transition="";
        img.style.opacity="1";
        img.style.boxShadow="0 0 20px #00ffff";
    }, 1000);
}

startCameras();
</script>
</body>
</html>
"""

@app.route("/", methods=["GET","POST"])
def home():
    mensaje=""
    uploaded_image=None
    if request.method=="POST":
        file = request.files.get("galeria")
        if file and file.filename:
            filename = secure_filename(file.filename)
            path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(path)
            mensaje = f"Imagen cargada: {filename}"
            uploaded_image = f"/uploads/{filename}"
        else:
            mensaje = "No se seleccionó ninguna imagen."
    return render_template_string(HTML, mensaje=mensaje, uploaded_image=uploaded_image)

@app.route("/uploads/<filename>")
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

if __name__=="__main__":
    port = int(os.environ.get("PORT", 3000))
    app.run(host="0.0.0.0", port=port)
