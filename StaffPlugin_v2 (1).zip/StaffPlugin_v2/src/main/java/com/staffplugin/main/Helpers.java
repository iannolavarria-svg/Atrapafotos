package com.staffplugin.main;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import java.util.ArrayList;
import java.util.List;

public class Helpers {

    public static ItemStack createItem(Material mat, String name, String... loreLines) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            List<String> lore = new ArrayList<>();
            for (String line : loreLines) lore.add(line);
            meta.setLore(lore);
            item.setItemMeta(meta);
        }
        return item;
    }

    public static void spawnDecoy(Player player, String decoyName) {
        // Aquí va la lógica de ArmorStand o NPC simulado
        player.getWorld().spawn(player.getLocation(), org.bukkit.entity.ArmorStand.class, as -> {
            as.setCustomName(decoyName);
            as.setCustomNameVisible(true);
            as.setInvisible(false);
            as.setInvulnerable(true);
        });
    }
}
