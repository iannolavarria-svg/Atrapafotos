package com.staffplugin.main.menus;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import java.util.ArrayList;
import java.util.List;
import com.staffplugin.main.Main;

public class TrollMenu {

    private final Main plugin;

    public TrollMenu(Main plugin) { this.plugin = plugin; }

    public void open(Player staff, Player target) {
        Inventory inv = Bukkit.createInventory(null, 9, "Troll Menu");

        addTrollItem(inv, Material.SNOWBALL, "Lanzar Bola");
        addTrollItem(inv, Material.FIRE_CHARGE, "Fuego");
        addTrollItem(inv, Material.ENDER_PEARL, "Teletransportar");
        addTrollItem(inv, Material.LEAD, "Atar");

        staff.openInventory(inv);
    }

    private void addTrollItem(Inventory inv, Material mat, String name) {
        ItemStack it = new ItemStack(mat);
        ItemMeta meta = it.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            List<String> lore = new ArrayList<>();
            lore.add("Click para ejecutar acción: " + name);
            meta.setLore(lore);
            it.setItemMeta(meta);
        }
        inv.addItem(it);
    }
}
