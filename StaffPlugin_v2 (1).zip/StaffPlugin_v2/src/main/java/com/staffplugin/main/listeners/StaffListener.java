package com.staffplugin.main.listeners;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.entity.ArmorStand;
import org.bukkit.event.Listener;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.block.Action;
import org.bukkit.inventory.ItemStack;
import com.staffplugin.main.Main;

public class StaffListener implements Listener {

    private final Main plugin;

    public StaffListener(Main plugin) {
        this.plugin = plugin;
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    @EventHandler
    public void onPlayerInteractEntity(PlayerInteractEntityEvent e) {
        Player staff = e.getPlayer();
        if (!plugin.staffManager.isStaff(staff)) return;

        ItemStack hand = staff.getInventory().getItemInMainHand();
        if (hand == null) return;

        Material mat = hand.getType();

        // Ban Hammer
        if (mat == Material.NETHERITE_AXE) {
            if (e.getRightClicked() instanceof Player target) {
                plugin.banManager.pendingBan.put(staff.getUniqueId(), target.getUniqueId());
                plugin.getBanMenu().open(staff, target);
                staff.sendMessage("BanMenu abierto para " + target.getName());
                e.setCancelled(true);
            } else if (e.getRightClicked() instanceof ArmorStand as) {
                plugin.decoyManager.removeDecoy(as);
                staff.sendMessage("Señuelo eliminado.");
                e.setCancelled(true);
            }
            return;
        }

        // Inspect Rod
        if (mat == Material.BLAZE_ROD) {
            if (e.getRightClicked() instanceof Player target) {
                staff.openInventory(target.getInventory());
                plugin.freezeManager.freeze(target);
                staff.sendMessage("Jugador inspeccionado y congelado: " + target.getName());
                e.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent e) {
        Player staff = e.getPlayer();
        if (!plugin.staffManager.isStaff(staff)) return;

        Action action = e.getAction();
        if (!(action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK)) return;

        ItemStack hand = staff.getInventory().getItemInMainHand();
        if (hand == null) return;

        Material mat = hand.getType();

        // Noclip toggle
        if (mat == Material.FEATHER) {
            plugin.tpManager.toggleNoclip(staff);
            e.setCancelled(true);
            return;
        }

        // TP Compass
        if (mat == Material.COMPASS) {
            plugin.tpManager.openTPMenu(staff);
            e.setCancelled(true);
            return;
        }

        // Decoy spawn
        if (mat == Material.NETHER_STAR) {
            plugin.decoyManager.spawnDecoy(staff.getLocation(), staff.getName() + "_decoy");
            staff.sendMessage("Señuelo spawneado.");
            e.setCancelled(true);
            return;
        }

        // Vanish toggle
        if (mat == Material.TOTEM_OF_UNDYING) {
            plugin.tpManager.toggleVanish(staff);
            e.setCancelled(true);
            return;
        }
    }
}
