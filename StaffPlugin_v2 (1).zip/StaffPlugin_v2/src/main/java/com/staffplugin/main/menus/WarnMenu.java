package com.staffplugin.main.menus;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.Material;
import org.bukkit.inventory.meta.ItemMeta;
import java.util.ArrayList;
import java.util.List;
import com.staffplugin.main.Main;

public class WarnMenu {

    private final Main plugin;

    public WarnMenu(Main plugin) { this.plugin = plugin; }

    public void open(Player staff, Player target) {
        Inventory inv = Bukkit.createInventory(null, 9, "Warn Menu");

        addPreset(inv, "Advertencia leve");
        addPreset(inv, "Advertencia media");
        addPreset(inv, "Advertencia grave");

        staff.openInventory(inv);
    }

    private void addPreset(Inventory inv, String preset) {
        ItemStack it = new ItemStack(Material.PAPER);
        ItemMeta meta = it.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(preset);
            List<String> lore = new ArrayList<>();
            lore.add("Click para enviar: " + preset);
            meta.setLore(lore);
            it.setItemMeta(meta);
        }
        inv.addItem(it);
    }
}
