package com.staffplugin.main.menus;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.Material;
import org.bukkit.inventory.meta.SkullMeta;
import com.staffplugin.main.Main;

public class TPMenu {

    private final Main plugin;

    public TPMenu(Main plugin) { this.plugin = plugin; }

    public void openTPMenu(Player staff) {
        Inventory inv = Bukkit.createInventory(null, 9*3, "TP Menu");
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.equals(staff)) continue;
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta) head.getItemMeta();
            if (meta != null) {
                meta.setDisplayName(p.getName());
                try { meta.setOwningPlayer(p); } catch (Exception ignored) {}
                head.setItemMeta(meta);
                inv.addItem(head);
            }
        }
        staff.openInventory(inv);
    }
}
