package com.staffplugin.main.menus;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.Material;
import org.bukkit.inventory.meta.ItemMeta;
import java.util.ArrayList;
import java.util.List;
import com.staffplugin.main.Main;

public class BanMenu {

    private final Main plugin;

    public BanMenu(Main plugin) { this.plugin = plugin; }

    public void open(Player staff, Player target) {
        Inventory inv = Bukkit.createInventory(null, 9, "Ban Menu");
        addPreset(inv, "10m");
        addPreset(inv, "1h");
        addPreset(inv, "1d");
        addPreset(inv, "7d");
        addPreset(inv, "perma");
        staff.openInventory(inv);
    }

    private void addPreset(Inventory inv, String preset) {
        ItemStack it = new ItemStack(Material.PAPER);
        ItemMeta meta = it.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(preset);
            List<String> lore = new ArrayList<>();
            lore.add("Click para banear con duración " + preset);
            meta.setLore(lore);
            it.setItemMeta(meta);
        }
        inv.addItem(it);
    }
}
