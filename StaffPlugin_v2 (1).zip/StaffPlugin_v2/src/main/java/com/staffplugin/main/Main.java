package com.staffplugin.main;

import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin {

    public StaffManager staffManager;
    public BanManager banManager;
    public TPManager tpManager;
    public DecoyManager decoyManager;
    public FreezeManager freezeManager;

    @Override
    public void onEnable() {
        getLogger().info("StaffPlugin activado!");
    }

    @Override
    public void onDisable() {
        getLogger().info("StaffPlugin desactivado!");
    }
}
